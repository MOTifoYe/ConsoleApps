﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            double q,w,x,y; 

            Console.WriteLine("введите первое число");
            q = Convert.ToDouble(Console.ReadLine()); 
            Console.WriteLine("введите второе число");
            w = Convert.ToDouble(Console.ReadLine());

            x = (2 / (Math.Pow(q, 2) + 25) + w) / (Math.Sqrt(w) + (q + w) / 2);
            Console.WriteLine($"x = {x}");

            y = (Math.Abs(q) + 2 * Math.Sin(w)) / (5.5 * q);
            Console.WriteLine($"y = {y}");
        }
    }
}
